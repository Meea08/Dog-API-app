package meea.uid.subject3_muresansalomeea.dto

data class ImageResponse(
    val message: List<String>,
    val status: String
)
