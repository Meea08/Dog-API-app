package meea.uid.subject3_muresansalomeea.model

class BreedGenerator {
    companion object {
        fun generate(): ArrayList<BreedModel> {
            val response = ArrayList<BreedModel>()

            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))
            response.add(BreedModel("rasa 1",))

            return response
        }
    }
}