package meea.uid.subject3_muresansalomeea.model


data class BreedModel(
    val breed: String
)
